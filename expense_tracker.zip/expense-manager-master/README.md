# Javascript Expense Manager
An Expense Manager project with graphs

This repository is a reference codebase for creating an Expense manager with Javascript.
